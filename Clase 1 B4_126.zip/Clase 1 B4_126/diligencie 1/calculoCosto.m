function J = calculoCosto(X, y, theta)
%   Esta funcion calcula el costo de usar Theta como los parametros para 
%   la regresion lineal cuando se ajustan los puntos en los datos de "X" y "y" 


end
