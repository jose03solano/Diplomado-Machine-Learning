function [theta, J_history] = gradienteDescendiente(X, y, theta, alpha, num_iters)

end
