
function visualizaCosto(X,y,t) 

% Malla sobre la cual se calculara J 

theta0_temp = linspace(-10, 10, 100);       
theta1_temp = linspace(-1, 4, 100);

% Se inicializa J_temp con una matriz de ceros 
J_temp = zeros(length(theta0_temp), length(theta1_temp));

% Se rellena cada valor de J_temp
for i = 1:length(theta0_temp)
    for j = 1:length(theta1_temp)
	  t = [theta0_temp(i); theta1_temp(j)];    
	  J_temp(i,j) = calculoCosto(X, y, t);
    end
end

J_temp = J_temp';
% Surface plot
figure;
surf(theta0_vals, theta1_vals, J_vals)
xlabel('\theta_0'); ylabel('\theta_1');

end