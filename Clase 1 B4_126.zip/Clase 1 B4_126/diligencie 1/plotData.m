function plotData(x, y)
%Use la funcion plot para crear una nueva figura de los puntos de los datos
%Debe de ponerle los nombres de a los ejes usando los comandos "xlabel" y "ylabel" 



end
