
%% DIPLOMADO MACHINE LEARNING UdeA
%% Grupo ANFI
%%
%% Instrucciones sobre los pasos a seguir para completar la primera tarea fprintf('Mi primera tarea ...\n')
%%

%1. Cargar los datos
%   use la funcion load('nombredelarchivo.txt');
%



%2. Grafique 
%   Construya una funcion y usela para graficar los datos. Llamela "PlotData" 
%   Para graficar tengqa en cuenta que "X" es la primera columna y "y" es la 
%   segunda columna de la matriz (conjunto) de los datos %pause
%



%3. HITO: Hallar los parametros Theta
%   Para hallar los Theta se debe optimizar la funcion de costos pero primero 
%   se debe construir. Entonces construya una funcion y llamela "calculoCosto" 
%   que reciba los tres argumentos X,y,Theta

calculoCosto(X, y, theta)



%4. HITO: Hallar los parametros Theta
%   Para hallar los Theta se debe optimizar la funcion de costos usando el algoritmo 
%   gradiente descendiente. Entonces construya una funcion llamada "gradienteDescendiente" para
%   aprender Theta. El programa debe ir actualizando Theta hasta un numero de iteraciones fijado
%   y una tasa de aprendizaje fija. Iteraciones=2000 alpha=0.01

theta = gradienteDescendiente(X, y, theta, alpha, iterations);





% visualice los parametros Theta encontrados - grafique la recta hallada - haga predicciones 
%fprintf('El Theta encontrado por el gradiente descendiente es: ');
%fprintf('%f %f \n', theta(1), theta(2));


%% superficie de la funcion J(theta_0, theta_1) 
%%
%%
visualizaCosto(X,y);






%% contornos de la funcion J(theta_0, theta_1) 
%%
%%
contornos(X,y,theta);

