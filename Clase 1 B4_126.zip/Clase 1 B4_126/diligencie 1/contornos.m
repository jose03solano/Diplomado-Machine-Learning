function contornosRe(X,y,theta) 

% Malla sobre la cual se calculara J 

theta0_temp = linspace(-10, 10, 100);       
theta1_temp = linspace(-1, 4, 100);

% Se inicializa J_temp con una matriz de ceros 
J_temp = zeros(length(theta0_temp), length(theta1_temp));

% Se rellena cada valor de J_temp
for i = 1:length(theta0_temp)
    for j = 1:length(theta1_temp)
	  t = [theta0_temp(i); theta1_temp(j)];    
	  J_temp(i,j) = calculoCostoRe(X, y, t);
    end
end

J_temp = J_temp';

figure;
% Plot J_temp como 15 contornos espaciados logaritmicamente entre 0.01 y 100
contour(theta0_temp, theta1_temp, J_temp, logspace(-2, 3, 20))
xlabel('\theta_0'); ylabel('\theta_1');
hold on;
plot(theta(1), theta(2), 'rx', 'MarkerSize', 10, 'LineWidth', 2);